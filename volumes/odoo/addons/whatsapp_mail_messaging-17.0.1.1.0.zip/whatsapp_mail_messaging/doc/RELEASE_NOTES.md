## Module <whatsapp_mail_messaging>

#### 01.03.2024
#### Version 17.0.1.0.0
##### ADD
- Initial commit for Odoo Whatsapp Connector
